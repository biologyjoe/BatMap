export interface BridgeData {
  id: number
  sfn: string
  oid: string
  location: { x: number; y: number }
  address: { city: string; state: string; formattedAddress: string }
  county_cd: string
  district: string
  rating: string
  population: string
  membrane: string
  managedBy: string
  odotDistrict: string
  yr_built: string
  nbis_bridge_length: number
  deck_area: number
  surveyType: string
  surveyDate: string
  batPopulation: number
  batSpeciesVerified: boolean
  batSpecies: string[]
  habitatInfo: {
    eco_region: string
    forest_distance: number
    water_distance: number
  }
  tosu: string
  typeSimp: string
  idConfidence: string
  dataSources: {
    name: string
    survey_date: string
    population: string
    bat_species_verified: boolean
    species: string[]
  }[]
}

export const mockBridges: BridgeData[] = [
  {
    id: 1,
    sfn: "1800357",
    oid: "OID-001",
    location: { x: 39.1075, y: -84.5120 },
    address: { city: "Cincinnati", state: "OH", formattedAddress: "I-75 over Mill Creek, Cincinnati, OH" },
    county_cd: "HAM",
    district: "8",
    rating: "6",
    population: "250",
    membrane: "Yes",
    managedBy: "ODOT",
    odotDistrict: "D08",
    yr_built: "1962",
    nbis_bridge_length: 320,
    deck_area: 12800,
    surveyType: "Visual Inspection",
    surveyDate: "09-15-2023",
    batPopulation: 250,
    batSpeciesVerified: true,
    batSpecies: ["Big Brown Bat", "Little Brown Bat"],
    habitatInfo: { eco_region: "Eastern Corn Belt Plains", forest_distance: 0.5, water_distance: 0.1 },
    tosu: "TOSU-A",
    typeSimp: "Steel Girder",
    idConfidence: "High",
    dataSources: [
      { name: "Visual Inspection", survey_date: "2023-09-15", population: "250", bat_species_verified: true, species: ["Big Brown Bat", "Little Brown Bat"] },
      { name: "Acoustic Survey", survey_date: "2022-06-20", population: "180", bat_species_verified: true, species: ["Big Brown Bat"] },
      { name: "Visual Inspection", survey_date: "2021-08-10", population: "120", bat_species_verified: false, species: [] },
    ]
  },
  {
    id: 2,
    sfn: "1800412",
    oid: "OID-002",
    location: { x: 39.1290, y: -84.5180 },
    address: { city: "Cincinnati", state: "OH", formattedAddress: "US-50 over Great Miami River, Cincinnati, OH" },
    county_cd: "HAM",
    district: "8",
    rating: "5",
    population: "85",
    membrane: "No",
    managedBy: "County",
    odotDistrict: "D08",
    yr_built: "1978",
    nbis_bridge_length: 185,
    deck_area: 7400,
    surveyType: "Acoustic Survey",
    surveyDate: "07-22-2023",
    batPopulation: 85,
    batSpeciesVerified: true,
    batSpecies: ["Indiana Bat", "Northern Long-eared Bat"],
    habitatInfo: { eco_region: "Interior Plateau", forest_distance: 1.2, water_distance: 0.05 },
    tosu: "TOSU-B",
    typeSimp: "Concrete Slab",
    idConfidence: "Medium",
    dataSources: [
      { name: "Acoustic Survey", survey_date: "2023-07-22", population: "85", bat_species_verified: true, species: ["Indiana Bat", "Northern Long-eared Bat"] },
      { name: "Visual Inspection", survey_date: "2021-05-15", population: "60", bat_species_verified: false, species: [] },
    ]
  },
  {
    id: 3,
    sfn: "2501033",
    oid: "OID-003",
    location: { x: 39.7589, y: -84.1916 },
    address: { city: "Dayton", state: "OH", formattedAddress: "SR-49 over Great Miami River, Dayton, OH" },
    county_cd: "MON",
    district: "7",
    rating: "7",
    population: "420",
    membrane: "Yes",
    managedBy: "ODOT",
    odotDistrict: "D07",
    yr_built: "1955",
    nbis_bridge_length: 450,
    deck_area: 18000,
    surveyType: "Emergence Count",
    surveyDate: "08-05-2023",
    batPopulation: 420,
    batSpeciesVerified: true,
    batSpecies: ["Big Brown Bat", "Evening Bat", "Tri-colored Bat"],
    habitatInfo: { eco_region: "Eastern Corn Belt Plains", forest_distance: 0.3, water_distance: 0.02 },
    tosu: "TOSU-A",
    typeSimp: "Steel Truss",
    idConfidence: "High",
    dataSources: [
      { name: "Emergence Count", survey_date: "2023-08-05", population: "420", bat_species_verified: true, species: ["Big Brown Bat", "Evening Bat", "Tri-colored Bat"] },
      { name: "Acoustic Survey", survey_date: "2022-07-18", population: "380", bat_species_verified: true, species: ["Big Brown Bat", "Evening Bat"] },
      { name: "Visual Inspection", survey_date: "2020-09-01", population: "200", bat_species_verified: false, species: [] },
    ]
  },
  {
    id: 4,
    sfn: "3200789",
    oid: "OID-004",
    location: { x: 39.9612, y: -82.9988 },
    address: { city: "Columbus", state: "OH", formattedAddress: "I-70 over Scioto River, Columbus, OH" },
    county_cd: "FRA",
    district: "6",
    rating: "4",
    population: "0",
    membrane: "No",
    managedBy: "ODOT",
    odotDistrict: "D06",
    yr_built: "1970",
    nbis_bridge_length: 280,
    deck_area: 11200,
    surveyType: "Visual Inspection",
    surveyDate: "10-12-2023",
    batPopulation: 0,
    batSpeciesVerified: false,
    batSpecies: [],
    habitatInfo: { eco_region: "Eastern Corn Belt Plains", forest_distance: 2.1, water_distance: 0.01 },
    tosu: "TOSU-C",
    typeSimp: "Concrete Box Beam",
    idConfidence: "N/A",
    dataSources: [
      { name: "Visual Inspection", survey_date: "2023-10-12", population: "0", bat_species_verified: false, species: [] },
    ]
  },
  {
    id: 5,
    sfn: "4100234",
    oid: "OID-005",
    location: { x: 41.4993, y: -81.6944 },
    address: { city: "Cleveland", state: "OH", formattedAddress: "I-90 over Cuyahoga River, Cleveland, OH" },
    county_cd: "CUY",
    district: "12",
    rating: "5",
    population: "175",
    membrane: "Yes",
    managedBy: "ODOT",
    odotDistrict: "D12",
    yr_built: "1959",
    nbis_bridge_length: 520,
    deck_area: 26000,
    surveyType: "Acoustic Survey",
    surveyDate: "06-30-2023",
    batPopulation: 175,
    batSpeciesVerified: true,
    batSpecies: ["Big Brown Bat", "Silver-haired Bat"],
    habitatInfo: { eco_region: "Erie Drift Plain", forest_distance: 1.5, water_distance: 0.03 },
    tosu: "TOSU-A",
    typeSimp: "Steel Girder",
    idConfidence: "High",
    dataSources: [
      { name: "Acoustic Survey", survey_date: "2023-06-30", population: "175", bat_species_verified: true, species: ["Big Brown Bat", "Silver-haired Bat"] },
      { name: "Emergence Count", survey_date: "2022-08-14", population: "150", bat_species_verified: true, species: ["Big Brown Bat"] },
    ]
  },
  {
    id: 6,
    sfn: "5500678",
    oid: "OID-006",
    location: { x: 41.0814, y: -81.5190 },
    address: { city: "Akron", state: "OH", formattedAddress: "SR-8 over Little Cuyahoga River, Akron, OH" },
    county_cd: "SUM",
    district: "4",
    rating: "6",
    population: "310",
    membrane: "No",
    managedBy: "City",
    odotDistrict: "D04",
    yr_built: "1985",
    nbis_bridge_length: 210,
    deck_area: 8400,
    surveyType: "Emergence Count",
    surveyDate: "07-11-2023",
    batPopulation: 310,
    batSpeciesVerified: true,
    batSpecies: ["Big Brown Bat", "Little Brown Bat", "Indiana Bat"],
    habitatInfo: { eco_region: "Erie Drift Plain", forest_distance: 0.8, water_distance: 0.15 },
    tosu: "TOSU-B",
    typeSimp: "Prestressed Concrete",
    idConfidence: "High",
    dataSources: [
      { name: "Emergence Count", survey_date: "2023-07-11", population: "310", bat_species_verified: true, species: ["Big Brown Bat", "Little Brown Bat", "Indiana Bat"] },
      { name: "Visual Inspection", survey_date: "2022-04-20", population: "200", bat_species_verified: true, species: ["Big Brown Bat"] },
      { name: "Acoustic Survey", survey_date: "2021-06-05", population: "150", bat_species_verified: false, species: [] },
    ]
  },
  {
    id: 7,
    sfn: "6200145",
    oid: "OID-007",
    location: { x: 41.6528, y: -83.5379 },
    address: { city: "Toledo", state: "OH", formattedAddress: "I-280 over Maumee River, Toledo, OH" },
    county_cd: "LUC",
    district: "2",
    rating: "7",
    population: "50",
    membrane: "Yes",
    managedBy: "ODOT",
    odotDistrict: "D02",
    yr_built: "1967",
    nbis_bridge_length: 380,
    deck_area: 15200,
    surveyType: "Visual Inspection",
    surveyDate: "05-20-2023",
    batPopulation: 50,
    batSpeciesVerified: false,
    batSpecies: [],
    habitatInfo: { eco_region: "Huron/Erie Lake Plains", forest_distance: 3.0, water_distance: 0.01 },
    tosu: "TOSU-C",
    typeSimp: "Steel Girder",
    idConfidence: "Low",
    dataSources: [
      { name: "Visual Inspection", survey_date: "2023-05-20", population: "50", bat_species_verified: false, species: [] },
    ]
  },
  {
    id: 8,
    sfn: "7800456",
    oid: "OID-008",
    location: { x: 40.7989, y: -81.3784 },
    address: { city: "Canton", state: "OH", formattedAddress: "US-62 over Nimishillen Creek, Canton, OH" },
    county_cd: "STK",
    district: "4",
    rating: "5",
    population: "130",
    membrane: "No",
    managedBy: "County",
    odotDistrict: "D04",
    yr_built: "1973",
    nbis_bridge_length: 150,
    deck_area: 6000,
    surveyType: "Acoustic Survey",
    surveyDate: "08-28-2023",
    batPopulation: 130,
    batSpeciesVerified: true,
    batSpecies: ["Big Brown Bat", "Eastern Red Bat"],
    habitatInfo: { eco_region: "Erie Drift Plain", forest_distance: 0.6, water_distance: 0.2 },
    tosu: "TOSU-A",
    typeSimp: "Concrete Slab",
    idConfidence: "Medium",
    dataSources: [
      { name: "Acoustic Survey", survey_date: "2023-08-28", population: "130", bat_species_verified: true, species: ["Big Brown Bat", "Eastern Red Bat"] },
      { name: "Visual Inspection", survey_date: "2022-03-15", population: "90", bat_species_verified: false, species: [] },
    ]
  },
  {
    id: 9,
    sfn: "3300912",
    oid: "OID-009",
    location: { x: 39.3292, y: -82.1013 },
    address: { city: "Athens", state: "OH", formattedAddress: "US-33 over Hocking River, Athens, OH" },
    county_cd: "ATH",
    district: "10",
    rating: "6",
    population: "540",
    membrane: "Yes",
    managedBy: "ODOT",
    odotDistrict: "D10",
    yr_built: "1948",
    nbis_bridge_length: 290,
    deck_area: 11600,
    surveyType: "Emergence Count",
    surveyDate: "07-05-2023",
    batPopulation: 540,
    batSpeciesVerified: true,
    batSpecies: ["Big Brown Bat", "Little Brown Bat", "Indiana Bat", "Tri-colored Bat"],
    habitatInfo: { eco_region: "Western Allegheny Plateau", forest_distance: 0.1, water_distance: 0.05 },
    tosu: "TOSU-A",
    typeSimp: "Steel Truss",
    idConfidence: "High",
    dataSources: [
      { name: "Emergence Count", survey_date: "2023-07-05", population: "540", bat_species_verified: true, species: ["Big Brown Bat", "Little Brown Bat", "Indiana Bat", "Tri-colored Bat"] },
      { name: "Acoustic Survey", survey_date: "2022-06-12", population: "480", bat_species_verified: true, species: ["Big Brown Bat", "Little Brown Bat", "Indiana Bat"] },
      { name: "Visual Inspection", survey_date: "2021-09-18", population: "350", bat_species_verified: true, species: ["Big Brown Bat"] },
      { name: "Visual Inspection", survey_date: "2019-05-22", population: "200", bat_species_verified: false, species: [] },
    ]
  },
  {
    id: 10,
    sfn: "4400567",
    oid: "OID-010",
    location: { x: 40.3420, y: -83.7720 },
    address: { city: "Lima", state: "OH", formattedAddress: "I-75 over Ottawa River, Lima, OH" },
    county_cd: "ALL",
    district: "1",
    rating: "7",
    population: "15",
    membrane: "No",
    managedBy: "ODOT",
    odotDistrict: "D01",
    yr_built: "1990",
    nbis_bridge_length: 175,
    deck_area: 7000,
    surveyType: "Visual Inspection",
    surveyDate: "09-28-2023",
    batPopulation: 15,
    batSpeciesVerified: false,
    batSpecies: [],
    habitatInfo: { eco_region: "Eastern Corn Belt Plains", forest_distance: 2.5, water_distance: 0.1 },
    tosu: "TOSU-C",
    typeSimp: "Prestressed Concrete",
    idConfidence: "Low",
    dataSources: [
      { name: "Visual Inspection", survey_date: "2023-09-28", population: "15", bat_species_verified: false, species: [] },
    ]
  },
]

// Dashboard summary data
export const dashboardStats = {
  totalBridges: mockBridges.length,
  bridgesWithBats: mockBridges.filter(b => b.batPopulation > 0).length,
  totalBatPopulation: mockBridges.reduce((sum, b) => sum + b.batPopulation, 0),
  speciesVerified: mockBridges.filter(b => b.batSpeciesVerified).length,
  avgRating: (mockBridges.reduce((sum, b) => sum + parseInt(b.rating), 0) / mockBridges.length).toFixed(1),
  districts: [...new Set(mockBridges.map(b => b.odotDistrict))].length,
}

export const populationByDistrict = [
  { district: "D01", population: 15, bridges: 1 },
  { district: "D02", population: 50, bridges: 1 },
  { district: "D04", population: 440, bridges: 2 },
  { district: "D06", population: 0, bridges: 1 },
  { district: "D07", population: 420, bridges: 1 },
  { district: "D08", population: 335, bridges: 2 },
  { district: "D10", population: 540, bridges: 1 },
  { district: "D12", population: 175, bridges: 1 },
]

export const speciesDistribution = [
  { name: "Big Brown Bat", count: 8 },
  { name: "Little Brown Bat", count: 3 },
  { name: "Indiana Bat", count: 3 },
  { name: "Tri-colored Bat", count: 2 },
  { name: "Northern Long-eared Bat", count: 1 },
  { name: "Evening Bat", count: 1 },
  { name: "Silver-haired Bat", count: 1 },
  { name: "Eastern Red Bat", count: 1 },
]

export const surveyTimeline = [
  { month: "Mar 2022", surveys: 1 },
  { month: "Apr 2022", surveys: 1 },
  { month: "Jun 2022", surveys: 2 },
  { month: "Jul 2022", surveys: 1 },
  { month: "Aug 2022", surveys: 1 },
  { month: "May 2023", surveys: 1 },
  { month: "Jun 2023", surveys: 2 },
  { month: "Jul 2023", surveys: 3 },
  { month: "Aug 2023", surveys: 2 },
  { month: "Sep 2023", surveys: 2 },
  { month: "Oct 2023", surveys: 1 },
]
