import { useState, useMemo } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet'
import { Icon } from 'leaflet'
import { FiChevronDown, FiChevronUp, FiArrowLeft } from 'react-icons/fi'
import { mockBridges } from '../data/mockData'

// Use default Leaflet marker
const MARKER = new Icon({
  iconUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
})

export default function BridgeProfile() {
  const { id } = useParams()
  const navigate = useNavigate()
  const bridge = useMemo(() => mockBridges.find(b => b.id === Number(id)), [id])

  const [activeTab, setActiveTab] = useState<'info' | 'bat' | 'habitat'>('info')
  const [selectedDsIndex, setSelectedDsIndex] = useState(0)
  const [historyOpen, setHistoryOpen] = useState(true)

  if (!bridge) {
    return (
      <div style={{ textAlign: 'center', padding: 60 }}>
        <h2 style={{ color: 'var(--color-text-muted)' }}>Bridge not found</h2>
        <button className="btn btn-ghost" style={{ marginTop: 16 }} onClick={() => navigate('/bridges')}>
          <FiArrowLeft /> Back to list
        </button>
      </div>
    )
  }

  const ds = bridge.dataSources[selectedDsIndex]

  return (
    <div>
      {/* Back + Heading */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 16, marginBottom: 24 }} className="fade-in">
        <button className="btn btn-ghost" onClick={() => navigate('/bridges')}>
          <FiArrowLeft size={16} /> Back
        </button>
        <div>
          <h2 style={{ fontSize: '1.55rem', fontWeight: 700, letterSpacing: '-0.03em' }}>
            Bridge Profile — <span style={{ color: 'var(--color-primary)', fontFamily: 'var(--font-mono)' }}>{bridge.sfn}</span>
          </h2>
          <p style={{ fontSize: '0.85rem', color: 'var(--color-text-muted)' }}>
            {bridge.address.formattedAddress}
          </p>
        </div>
      </div>

      {/* Tabs */}
      <div className="tab-row fade-in fade-in-1">
        {(['info', 'bat', 'habitat'] as const).map(tab => (
          <button
            key={tab}
            className={`tab-btn ${activeTab === tab ? 'active' : ''}`}
            onClick={() => setActiveTab(tab)}
          >
            {tab === 'info' ? 'Bridge Info' : tab === 'bat' ? 'Bat Data' : 'Habitat'}
          </button>
        ))}
      </div>

      <div className="grid-2" style={{ alignItems: 'start' }}>
        {/* Left: Content based on active tab */}
        <div className="card fade-in fade-in-2">
          <div className="card-body">
            {activeTab === 'info' && (
              <div>
                <DetailRow label="SFN" value={bridge.sfn} />
                <DetailRow label="OID" value={bridge.oid} />
                <DetailRow label="Location" value={`${bridge.address.city}, ${bridge.address.state}`} />
                <DetailRow label="ODOT District" value={bridge.odotDistrict} />
                <DetailRow label="County" value={bridge.county_cd} />
                <DetailRow label="Managed By" value={bridge.managedBy} />
                <DetailRow label="Rating" value={bridge.rating} />
                <DetailRow label="Type" value={bridge.typeSimp} />
                <DetailRow label="TOSU" value={bridge.tosu} />
                <DetailRow label="Membrane" value={bridge.membrane} />
                <DetailRow label="Year Built" value={bridge.yr_built} />
                <DetailRow label="Bridge Length" value={`${bridge.nbis_bridge_length} ft`} />
                <DetailRow label="Deck Area" value={`${bridge.deck_area.toLocaleString()} sq ft`} />
                <DetailRow label="ID Confidence" value={bridge.idConfidence} />
              </div>
            )}

            {activeTab === 'bat' && (
              <div>
                <DetailRow label="Current Population" value={
                  <span className={`badge ${bridge.batPopulation > 200 ? 'teal' : bridge.batPopulation > 0 ? 'amber' : 'red'}`}>
                    {bridge.batPopulation}
                  </span>
                } />
                <DetailRow label="Species Verified" value={
                  <span className={`badge ${bridge.batSpeciesVerified ? 'green' : 'red'}`}>
                    {bridge.batSpeciesVerified ? 'Yes' : 'No'}
                  </span>
                } />
                {bridge.batSpecies.length > 0 && (
                  <DetailRow label="Bat Species" value={
                    <div style={{ display: 'flex', flexWrap: 'wrap', gap: 4 }}>
                      {bridge.batSpecies.map(s => <span key={s} className="species-tag">{s}</span>)}
                    </div>
                  } />
                )}

                {/* Selected data source info */}
                <div style={{ marginTop: 20, borderTop: '1px solid var(--color-border)', paddingTop: 16 }}>
                  <h4 style={{ fontSize: '0.9rem', fontWeight: 600, marginBottom: 12, color: 'var(--color-text-secondary)' }}>
                    Data Source: {ds.name}
                  </h4>
                  <DetailRow label="Survey Date" value={new Date(ds.survey_date).toLocaleDateString()} />
                  <DetailRow label="Population" value={ds.population} />
                  <DetailRow label="Species Verified" value={ds.bat_species_verified ? 'Yes' : 'No'} />
                  {ds.species.length > 0 && (
                    <DetailRow label="Species" value={
                      <div style={{ display: 'flex', flexWrap: 'wrap', gap: 4 }}>
                        {ds.species.map(s => <span key={s} className="species-tag">{s}</span>)}
                      </div>
                    } />
                  )}
                </div>

                {/* Data Source History */}
                <div style={{ marginTop: 20 }}>
                  <div className="collapsible-header" onClick={() => setHistoryOpen(!historyOpen)}>
                    <span style={{ fontWeight: 600, fontSize: '0.85rem' }}>Data Source History</span>
                    {historyOpen ? <FiChevronUp size={16} /> : <FiChevronDown size={16} />}
                  </div>
                  {historyOpen && (
                    <div style={{ marginTop: 8 }}>
                      {bridge.dataSources.map((src, i) => (
                        <div
                          key={i}
                          className={`ds-history-row ${selectedDsIndex === i ? 'active' : ''}`}
                          onClick={() => setSelectedDsIndex(i)}
                          style={{ padding: '10px 12px', borderRadius: 'var(--radius-sm)' }}
                        >
                          <span style={{ flex: 1 }}>{src.name}</span>
                          <span style={{ color: 'var(--color-text-muted)', fontFamily: 'var(--font-mono)', fontSize: '0.82rem' }}>
                            {new Date(src.survey_date).toLocaleDateString()}
                          </span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            )}

            {activeTab === 'habitat' && (
              <div>
                <DetailRow label="Eco Region" value={bridge.habitatInfo.eco_region} />
                <DetailRow label="Distance to Forest" value={`${bridge.habitatInfo.forest_distance} mile${bridge.habitatInfo.forest_distance !== 1 ? 's' : ''}`} />
                <DetailRow label="Distance to Water" value={`${bridge.habitatInfo.water_distance} mile${bridge.habitatInfo.water_distance !== 1 ? 's' : ''}`} />
                <DetailRow label="Survey Type" value={bridge.surveyType} />
                <DetailRow label="Last Survey Date" value={bridge.surveyDate} />
              </div>
            )}
          </div>
        </div>

        {/* Right: Map */}
        <div className="card fade-in fade-in-3" style={{ position: 'sticky', top: 'calc(var(--header-height) + 20px)' }}>
          <div className="card-header">Location</div>
          <div style={{ height: 500 }}>
            <MapContainer
              center={[bridge.location.x, bridge.location.y]}
              zoom={14}
              style={{ height: '100%', width: '100%' }}
            >
              <TileLayer
                attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
                url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
              />
              <Marker
                position={[bridge.location.x, bridge.location.y]}
                icon={MARKER}
              >
                <Popup>
                  <div>
                    <strong style={{ color: '#1a1a2e' }}>{bridge.sfn}</strong>
                    <br />
                    <span style={{ fontSize: '0.82rem', color: '#555' }}>{bridge.address.formattedAddress}</span>
                  </div>
                </Popup>
              </Marker>
            </MapContainer>
          </div>
        </div>
      </div>
    </div>
  )
}

function DetailRow({ label, value }: { label: string; value: React.ReactNode }) {
  return (
    <div className="detail-row">
      <div className="detail-label">{label}</div>
      <div className="detail-value">{value}</div>
    </div>
  )
}
