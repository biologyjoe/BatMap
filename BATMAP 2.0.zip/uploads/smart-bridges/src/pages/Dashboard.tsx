import { useMemo } from 'react'
import { useNavigate } from 'react-router-dom'
import { MapContainer, TileLayer, CircleMarker, Popup } from 'react-leaflet'
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, AreaChart, Area,
} from 'recharts'
import { FiMapPin, FiActivity, FiCheckCircle, FiTrendingUp } from 'react-icons/fi'
import {
  mockBridges, dashboardStats, populationByDistrict,
  speciesDistribution, surveyTimeline,
} from '../data/mockData'

const COLORS = ['#48c9b0', '#2e86c1', '#f39c12', '#e74c3c', '#27ae60', '#8e44ad', '#d4ac0d', '#e67e22']

const CustomTooltip = ({ active, payload, label }: any) => {
  if (!active || !payload?.length) return null
  return (
    <div style={{
      background: 'var(--color-surface)',
      border: '1px solid var(--color-border)',
      borderRadius: 'var(--radius-sm)',
      padding: '10px 14px',
      fontSize: '0.82rem',
    }}>
      <div style={{ fontWeight: 600, marginBottom: 4, color: 'var(--color-text)' }}>{label}</div>
      {payload.map((p: any, i: number) => (
        <div key={i} style={{ color: p.color }}>
          {p.name}: {p.value}
        </div>
      ))}
    </div>
  )
}

export default function Dashboard() {
  const navigate = useNavigate()

  const stats = useMemo(() => [
    { label: 'Total Bridges', value: dashboardStats.totalBridges, icon: <FiMapPin />, colorClass: 'teal' },
    { label: 'Bridges w/ Bats', value: dashboardStats.bridgesWithBats, icon: <FiActivity />, colorClass: 'amber' },
    { label: 'Total Bat Population', value: dashboardStats.totalBatPopulation.toLocaleString(), icon: <FiTrendingUp />, colorClass: 'green' },
    { label: 'Species Verified', value: dashboardStats.speciesVerified, icon: <FiCheckCircle />, colorClass: 'teal' },
  ], [])

  return (
    <div>
      <div className="page-heading fade-in">
        <h2>Dashboard</h2>
        <p>Overview of Ohio bridge bat monitoring data</p>
      </div>

      {/* Stat Cards */}
      <div className="stat-grid">
        {stats.map((s, i) => (
          <div key={s.label} className={`stat-card fade-in fade-in-${i + 1}`}>
            <div className={`stat-icon ${s.colorClass}`}>{s.icon}</div>
            <div className="stat-info">
              <div className="stat-value">{s.value}</div>
              <div className="stat-label">{s.label}</div>
            </div>
          </div>
        ))}
      </div>

      {/* Charts Row */}
      <div className="grid-2" style={{ marginBottom: 20 }}>
        <div className="card fade-in fade-in-3">
          <div className="card-header">Population by District</div>
          <div className="card-body" style={{ height: 320 }}>
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={populationByDistrict}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="district" />
                <YAxis />
                <Tooltip content={<CustomTooltip />} />
                <Bar dataKey="population" name="Bat Population" fill="#48c9b0" radius={[4,4,0,0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="card fade-in fade-in-4">
          <div className="card-header">Species Distribution</div>
          <div className="card-body" style={{ height: 320, display: 'flex', alignItems: 'center' }}>
            <ResponsiveContainer width="55%" height="100%">
              <PieChart>
                <Pie
                  data={speciesDistribution}
                  cx="50%"
                  cy="50%"
                  outerRadius={100}
                  innerRadius={50}
                  dataKey="count"
                  nameKey="name"
                  stroke="none"
                >
                  {speciesDistribution.map((_, i) => (
                    <Cell key={i} fill={COLORS[i % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip content={<CustomTooltip />} />
              </PieChart>
            </ResponsiveContainer>
            <div style={{ flex: 1, fontSize: '0.8rem' }}>
              {speciesDistribution.map((s, i) => (
                <div key={s.name} style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 6 }}>
                  <div style={{
                    width: 10, height: 10, borderRadius: '50%',
                    background: COLORS[i % COLORS.length], flexShrink: 0,
                  }} />
                  <span style={{ color: 'var(--color-text-secondary)' }}>{s.name}</span>
                  <span style={{ marginLeft: 'auto', fontFamily: 'var(--font-mono)', color: 'var(--color-text-muted)' }}>{s.count}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Survey Timeline */}
      <div className="card fade-in fade-in-5" style={{ marginBottom: 20 }}>
        <div className="card-header">Survey Activity Timeline</div>
        <div className="card-body" style={{ height: 260 }}>
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={surveyTimeline}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="month" />
              <YAxis allowDecimals={false} />
              <Tooltip content={<CustomTooltip />} />
              <Area
                type="monotone"
                dataKey="surveys"
                name="Surveys"
                stroke="#48c9b0"
                fill="rgba(72,201,176,0.15)"
                strokeWidth={2}
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Map Overview */}
      <div className="card fade-in fade-in-6">
        <div className="card-header">Bridge Locations — Ohio</div>
        <div className="card-body" style={{ height: 450, padding: 0 }}>
          <MapContainer
            center={[40.0, -82.5]}
            zoom={7}
            style={{ height: '100%', width: '100%', borderRadius: '0 0 var(--radius-lg) var(--radius-lg)' }}
          >
            <TileLayer
              attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
              url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
            />
            {mockBridges.map(bridge => (
              <CircleMarker
                key={bridge.id}
                center={[bridge.location.x, bridge.location.y]}
                radius={Math.max(6, Math.sqrt(bridge.batPopulation) * 0.8)}
                fillColor={bridge.batPopulation > 200 ? '#48c9b0' : bridge.batPopulation > 0 ? '#f39c12' : '#e74c3c'}
                fillOpacity={0.7}
                stroke={true}
                color="rgba(255,255,255,0.3)"
                weight={1}
              >
                <Popup>
                  <div style={{ minWidth: 180 }}>
                    <div style={{ fontWeight: 700, fontSize: '0.95rem', marginBottom: 4, color: '#1a1a2e' }}>
                      {bridge.sfn}
                    </div>
                    <div style={{ fontSize: '0.82rem', color: '#555', marginBottom: 2 }}>
                      {bridge.address.city}, {bridge.address.state}
                    </div>
                    <div style={{ fontSize: '0.82rem', color: '#555', marginBottom: 8 }}>
                      Population: <strong>{bridge.batPopulation}</strong>
                    </div>
                    <button
                      className="popup-detail-btn"
                      onClick={() => navigate(`/bridge/${bridge.id}`)}
                    >
                      View Details
                    </button>
                  </div>
                </Popup>
              </CircleMarker>
            ))}
          </MapContainer>
        </div>
      </div>
    </div>
  )
}
