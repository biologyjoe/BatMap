import { useState, useMemo } from 'react'
import { useNavigate } from 'react-router-dom'
import { MapContainer, TileLayer, CircleMarker, Popup } from 'react-leaflet'
import { FiSearch, FiChevronUp, FiChevronDown } from 'react-icons/fi'
import { mockBridges, BridgeData } from '../data/mockData'

type SortKey = 'sfn' | 'oid' | 'odotDistrict' | 'county_cd' | 'surveyType' | 'surveyDate' | 'batPopulation'

export default function BridgeList() {
  const navigate = useNavigate()
  const [search, setSearch] = useState('')
  const [sortKey, setSortKey] = useState<SortKey>('sfn')
  const [sortAsc, setSortAsc] = useState(true)

  const filtered = useMemo(() => {
    const q = search.toLowerCase()
    let list = mockBridges.filter(b =>
      b.sfn.toLowerCase().includes(q) ||
      b.oid.toLowerCase().includes(q) ||
      b.county_cd.toLowerCase().includes(q) ||
      b.address.city.toLowerCase().includes(q) ||
      b.odotDistrict.toLowerCase().includes(q)
    )

    list.sort((a, b) => {
      let va: any = a[sortKey]
      let vb: any = b[sortKey]
      if (sortKey === 'batPopulation') {
        va = Number(va); vb = Number(vb)
      } else {
        va = String(va).toLowerCase(); vb = String(vb).toLowerCase()
      }
      if (va < vb) return sortAsc ? -1 : 1
      if (va > vb) return sortAsc ? 1 : -1
      return 0
    })

    return list
  }, [search, sortKey, sortAsc])

  const handleSort = (key: SortKey) => {
    if (sortKey === key) {
      setSortAsc(!sortAsc)
    } else {
      setSortKey(key)
      setSortAsc(true)
    }
  }

  const SortIcon = ({ col }: { col: SortKey }) => {
    if (sortKey !== col) return <FiChevronUp className="sort-icon" size={12} />
    return sortAsc
      ? <FiChevronUp className="sort-icon active" size={12} />
      : <FiChevronDown className="sort-icon active" size={12} />
  }

  const columns: { key: SortKey; label: string }[] = [
    { key: 'sfn', label: 'SFN' },
    { key: 'oid', label: 'OID' },
    { key: 'odotDistrict', label: 'District' },
    { key: 'county_cd', label: 'County' },
    { key: 'surveyType', label: 'Survey Type' },
    { key: 'surveyDate', label: 'Survey Date' },
    { key: 'batPopulation', label: 'Bat Population' },
  ]

  return (
    <div>
      <div className="page-heading fade-in">
        <h2>Bridge List</h2>
        <p>{filtered.length} bridges found</p>
      </div>

      <div className="grid-2" style={{ alignItems: 'start' }}>
        {/* Table */}
        <div className="card fade-in fade-in-1">
          <div className="card-body" style={{ padding: '16px 20px 0' }}>
            <div className="search-wrap">
              <FiSearch />
              <input
                className="search-input"
                placeholder="Search by SFN, OID, county, city, district..."
                value={search}
                onChange={e => setSearch(e.target.value)}
              />
            </div>
          </div>
          <div className="data-table-wrapper" style={{ maxHeight: 600, overflowY: 'auto' }}>
            <table className="data-table">
              <thead>
                <tr>
                  {columns.map(col => (
                    <th key={col.key} onClick={() => handleSort(col.key)}>
                      {col.label} <SortIcon col={col.key} />
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {filtered.map(bridge => (
                  <tr key={bridge.id} onClick={() => navigate(`/bridge/${bridge.id}`)}>
                    <td style={{ fontFamily: 'var(--font-mono)', fontWeight: 500 }}>{bridge.sfn}</td>
                    <td>{bridge.oid}</td>
                    <td>{bridge.odotDistrict}</td>
                    <td>{bridge.county_cd}</td>
                    <td>{bridge.surveyType}</td>
                    <td>{bridge.surveyDate}</td>
                    <td>
                      <span className={`badge ${bridge.batPopulation > 200 ? 'teal' : bridge.batPopulation > 0 ? 'amber' : 'red'}`}>
                        {bridge.batPopulation}
                      </span>
                    </td>
                  </tr>
                ))}
                {filtered.length === 0 && (
                  <tr>
                    <td colSpan={7} style={{ textAlign: 'center', padding: 40, color: 'var(--color-text-muted)' }}>
                      No bridges match your search.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Map */}
        <div className="card fade-in fade-in-2" style={{ position: 'sticky', top: 'calc(var(--header-height) + 20px)' }}>
          <div className="card-header">Map View</div>
          <div style={{ height: 600 }}>
            <MapContainer
              center={[40.0, -82.5]}
              zoom={7}
              style={{ height: '100%', width: '100%' }}
            >
              <TileLayer
                attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
                url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
              />
              {filtered.map(bridge => (
                <CircleMarker
                  key={bridge.id}
                  center={[bridge.location.x, bridge.location.y]}
                  radius={Math.max(6, Math.sqrt(bridge.batPopulation) * 0.8)}
                  fillColor={bridge.batPopulation > 200 ? '#48c9b0' : bridge.batPopulation > 0 ? '#f39c12' : '#e74c3c'}
                  fillOpacity={0.7}
                  stroke={true}
                  color="rgba(255,255,255,0.3)"
                  weight={1}
                >
                  <Popup>
                    <div style={{ minWidth: 180 }}>
                      <div style={{ fontWeight: 700, fontSize: '0.95rem', marginBottom: 4, color: '#1a1a2e' }}>
                        {bridge.sfn}
                      </div>
                      <div style={{ fontSize: '0.82rem', color: '#555', marginBottom: 2 }}>
                        {bridge.address.city}, {bridge.address.state}
                      </div>
                      <div style={{ fontSize: '0.82rem', color: '#555', marginBottom: 8 }}>
                        Pop: <strong>{bridge.batPopulation}</strong>
                      </div>
                      <button
                        className="popup-detail-btn"
                        onClick={() => navigate(`/bridge/${bridge.id}`)}
                      >
                        View Details
                      </button>
                    </div>
                  </Popup>
                </CircleMarker>
              ))}
            </MapContainer>
          </div>
        </div>
      </div>
    </div>
  )
}
