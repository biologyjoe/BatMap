import { useState } from 'react'
import { Routes, Route, NavLink, useLocation, Navigate } from 'react-router-dom'
import { FiMap, FiGrid, FiList, FiMenu, FiX } from 'react-icons/fi'
import Dashboard from './pages/Dashboard'
import BridgeList from './pages/BridgeList'
import BridgeProfile from './pages/BridgeProfile'

const navItems = [
  { to: '/dashboard', label: 'Dashboard', icon: <FiGrid /> },
  { to: '/bridges', label: 'Bridge List', icon: <FiList /> },
]

function App() {
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const location = useLocation()

  const getPageTitle = () => {
    if (location.pathname === '/dashboard') return 'Dashboard'
    if (location.pathname === '/bridges') return 'Bridge List'
    if (location.pathname.startsWith('/bridge/')) return 'Bridge Profile'
    return 'Smart Bridges'
  }

  return (
    <div className="app-layout">
      {/* Mobile overlay */}
      <div
        className={`sidebar-overlay ${sidebarOpen ? 'visible' : ''}`}
        onClick={() => setSidebarOpen(false)}
      />

      {/* Sidebar */}
      <aside className={`sidebar ${sidebarOpen ? 'open' : ''}`}>
        <div className="sidebar-brand">
          <div className="sidebar-brand-icon">
            <FiMap />
          </div>
          <div>
            <h1>Smart Bridges</h1>
            <span>ODOT Bat Monitoring</span>
          </div>
        </div>

        <nav className="sidebar-nav">
          <div className="sidebar-section-label">Navigation</div>
          {navItems.map(item => (
            <NavLink
              key={item.to}
              to={item.to}
              className={({ isActive }) => `sidebar-link ${isActive ? 'active' : ''}`}
              onClick={() => setSidebarOpen(false)}
            >
              {item.icon}
              {item.label}
            </NavLink>
          ))}
        </nav>

        <div className="sidebar-footer">
          ODOT &copy; {new Date().getFullYear()} &middot; IT Solutions Center
        </div>
      </aside>

      {/* Main content */}
      <div className="main-area">
        <header className="app-header">
          <div className="header-left">
            <button className="menu-toggle" onClick={() => setSidebarOpen(!sidebarOpen)}>
              {sidebarOpen ? <FiX size={20} /> : <FiMenu size={20} />}
            </button>
            <div className="header-breadcrumb">
              Smart Bridges <span>/</span> {getPageTitle()}
            </div>
          </div>
          <div className="header-right">
            <span style={{ fontSize: '0.78rem', color: 'var(--color-text-muted)' }}>
              v1.0.0 — Demo Mode
            </span>
          </div>
        </header>

        <main className="main-content">
          <Routes>
            <Route path="/dashboard" element={<Dashboard />} />
            <Route path="/bridges" element={<BridgeList />} />
            <Route path="/bridge/:id" element={<BridgeProfile />} />
            <Route path="*" element={<Navigate to="/dashboard" replace />} />
          </Routes>
        </main>

        <footer className="app-footer">
          <div>ODOT &copy; {new Date().getFullYear()}</div>
          <div>Developed by Information Technology Solutions Center</div>
        </footer>
      </div>
    </div>
  )
}

export default App
