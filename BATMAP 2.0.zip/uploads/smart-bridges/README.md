# Smart Bridges — ODOT Bat Monitoring Dashboard

A standalone web dashboard for monitoring bat populations across Ohio bridge infrastructure. Built with React, TypeScript, Vite, Leaflet maps, and Recharts.

> **Demo Mode** — This version runs entirely in the browser with mock data. No backend server or database required.

## Features

- **Dashboard** with summary statistics, population charts, species distribution, and survey timeline
- **Bridge List** with sortable/searchable table and interactive map view
- **Bridge Profile** with detailed info tabs (Bridge Info, Bat Data, Habitat), data source history, and location map
- **Responsive design** with collapsible sidebar for mobile

## Quick Start

```bash
npm install
npm run dev
```

Open [http://localhost:5173/smart-bridges/](http://localhost:5173/smart-bridges/)

## Build for Production

```bash
npm run build
```

Output is in the `dist/` folder, ready for static hosting.

## Deploy to GitHub Pages

### Option A: Automatic (GitHub Actions)

1. Push this repo to GitHub
2. Go to **Settings → Pages → Source** and select **GitHub Actions**
3. Every push to `main` will auto-deploy

### Option B: Manual

```bash
npm run deploy
```

This uses `gh-pages` to push the `dist/` folder to the `gh-pages` branch.

> **Important:** Update the `base` field in `vite.config.ts` to match your repo name if it differs from `smart-bridges`.

## Tech Stack

- **React 18** + TypeScript
- **Vite** for fast builds
- **React Router** (HashRouter for GitHub Pages compatibility)
- **Leaflet** / React-Leaflet for maps
- **Recharts** for charts
- **React Icons** for iconography

## Project Structure

```
src/
├── App.tsx            # Layout, routing, sidebar
├── main.tsx           # Entry point
├── data/
│   └── mockData.ts    # All bridge mock data
├── pages/
│   ├── Dashboard.tsx  # Stats, charts, map overview
│   ├── BridgeList.tsx # Sortable table + map
│   └── BridgeProfile.tsx  # Detail view with tabs
└── styles/
    └── global.css     # All styles
```
